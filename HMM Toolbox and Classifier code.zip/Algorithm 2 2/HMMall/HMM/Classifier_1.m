%%
%The Bond Graph Digital Twin generates training data (TD) to train the ML
%algorithm. The data is for "Bit Bounce (BB)", "Stick Slip (SS)", and "Whirling (WH)" and their
%2 levels "high (H)" and "low (L)"
%% Training for High Stick-Slip (TR_SS_H)
addpath(genpath('C:\Users\HMMall'))
data_1 = [TR_SS_H]';% Training Data High Stick-Slip
T_1 = size(data_1,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_1 = size(data_1,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_1 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_1 = 2; %Number of mixtures of Gaussians 
Q_1 = 4; % Number of hidden states.
left_right_1 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_1 = normalise(rand(Q_1,1));% Initial guess of state probabilities 
transmat0_1 = mk_stochastic(rand(Q_1,Q_1));% Initial guess of transition probabilities
[mu0_1, Sigma0_1] = mixgauss_init(Q_1*M_1, reshape(data_1, [O_1 T_1*nex_1]), 'full');
mu0_1 = reshape(mu0_1, [O_1 Q_1 M_1]);
Sigma0_1 = reshape(Sigma0_1, [O_1 O_1 Q_1 M_1]);
mixmat0_1 = mk_stochastic(rand(Q_1,M_1));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_1, prior1_1, transmat1_1, mu1_1, Sigma1_1, mixmat1_1] = ... 
mhmm_em(data_1, prior0_1, transmat0_1, mu0_1, Sigma0_1, mixmat0_1, 'max_iter', 40); 

plot (LL_1) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
disp('SS_H Trained!')