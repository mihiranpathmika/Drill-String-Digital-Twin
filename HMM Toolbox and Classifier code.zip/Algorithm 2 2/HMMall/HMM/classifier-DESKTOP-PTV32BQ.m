%%
%The Bond Graph Digital Twin generates training data (TD) to train the ML
%algorithm. The data is for "Bit Bounce (BB)", "Stick Slip (SS)", and "Whirling (WH)" and their
%2 levels "high (H)" and "low (L)"
%% Training for High Stick-Slip (TR_SS_H)
addpath(genpath('C:\Users\HMMall'))
data_1 = [TR_SS_H]';% Training Data Bit Bounce High
T_1 = size(data_1,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_1 = size(data_1,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_1 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_1 = 2; %Number of mixtures of Gaussians 
Q_1 = 4; % Number of hidden states.
left_right_1 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_1 = normalise(rand(Q_1,1));% Initial guess of state probabilities 
transmat0_1 = mk_stochastic(rand(Q_1,Q_1));% Initial guess of transition probabilities
[mu0_1, Sigma0_1] = mixgauss_init(Q_1*M_1, reshape(data_1, [O_1 T_1*nex_1]), 'full');
mu0_1 = reshape(mu0_1, [O_1 Q_1 M_1]);
Sigma0_1 = reshape(Sigma0_1, [O_1 O_1 Q_1 M_1]);
mixmat0_1 = mk_stochastic(rand(Q_1,M_1));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_1, prior1_1, transmat1_1, mu1_1, Sigma1_1, mixmat1_1] = ... 
mhmm_em(data_1, prior0_1, transmat0_1, mu0_1, Sigma0_1, mixmat0_1, 'max_iter', 40); 

plot (LL_1) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
%% Training for Low Stick-Slip (TR_SS_L)
addpath(genpath('C:\Users\HMMall'))
data_2 = [TR_SS_L]';% Training Data Bit Bounce High
T_2 = size(data_2,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_2 = size(data_2,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_2 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_2 = 2; %Number of mixtures of Gaussians 
Q_2 = 4; % Number of hidden states.
left_right_2 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_2 = normalise(rand(Q_2,1));% Initial guess of state probabilities 
transmat0_2 = mk_stochastic(rand(Q_2,Q_2));% Initial guess of transition probabilities
[mu0_2, Sigma0_2] = mixgauss_init(Q_2*M_2, reshape(data_2, [O_2 T_2*nex_2]), 'full');
mu0_2 = reshape(mu0_2, [O_2 Q_2 M_2]);
Sigma0_2 = reshape(Sigma0_2, [O_2 O_2 Q_2 M_2]);
mixmat0_2 = mk_stochastic(rand(Q_2,M_2));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_2, prior1_2, transmat1_2, mu1_2, Sigma1_2, mixmat1_2] = ... 
mhmm_em(data_2, prior0_2, transmat0_2, mu0_2, Sigma0_2, mixmat0_2, 'max_iter', 40); 

plot (LL_2) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.

%% Training for High Bit Bounce (TR_BB_H)
addpath(genpath('C:\Users\HMMall'))
data_3 = [TR_BB_H]';% Training Data Bit Bounce High
T_3 = size(data_3,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_3 = size(data_3,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_3 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_3 = 2; %Number of mixtures of Gaussians 
Q_3 = 4; % Number of hidden states.
left_right_3 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_3 = normalise(rand(Q_3,1));% Initial guess of state probabilities 
transmat0_3 = mk_stochastic(rand(Q_3,Q_3));% Initial guess of transition probabilities
[mu0_3, Sigma0_3] = mixgauss_init(Q_3*M_3, reshape(data_3, [O_3 T_3*nex_3]), 'full');
mu0_3 = reshape(mu0_3, [O_3 Q_3 M_3]);
Sigma0_3 = reshape(Sigma0_3, [O_3 O_3 Q_3 M_3]);
mixmat0_3 = mk_stochastic(rand(Q_3,M_3));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_3, prior1_3, transmat1_3, mu1_3, Sigma1_3, mixmat1_3] = ... 
mhmm_em(data_3, prior0_3, transmat0_3, mu0_3, Sigma0_3, mixmat0_3, 'max_iter', 40); 

plot (LL_3) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.

%% Training for Low Bit-Bounce (TR_BB_L)
addpath(genpath('C:\Users\HMMall'))
data_4 = [TR_BB_L]';% Training Data Bit Bounce High
T_4 = size(data_4,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_4 = size(data_4,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_4 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_4 = 2; %Number of mixtures of Gaussians 
Q_4 = 4; % Number of hidden states.
left_right_4 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_4 = normalise(rand(Q_4,1));% Initial guess of state probabilities 
transmat0_4 = mk_stochastic(rand(Q_4,Q_4));% Initial guess of transition probabilities
[mu0_4, Sigma0_4] = mixgauss_init(Q_4*M_4, reshape(data_4, [O_4 T_4*nex_4]), 'full');
mu0_4 = reshape(mu0_4, [O_4 Q_4 M_4]);
Sigma0_4 = reshape(Sigma0_4, [O_4 O_4 Q_4 M_4]);
mixmat0_4 = mk_stochastic(rand(Q_4,M_4));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_4, prior1_4, transmat1_4, mu1_4, Sigma1_4, mixmat1_4] = ... 
mhmm_em(data_4, prior0_4, transmat0_4, mu0_4, Sigma0_4, mixmat0_4, 'max_iter', 40); 

plot (LL_4) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.

%% Training for High Bit Bounce (TR_WH_H)
addpath(genpath('C:\Users\HMMall'))
data_5 = [TR_WH_H]';% Training Data Bit Bounce High
T_5 = size(data_5,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_5 = size(data_5,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_5 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_5 = 2; %Number of mixtures of Gaussians 
Q_5 = 4; % Number of hidden states.
left_right_5 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_5 = normalise(rand(Q_5,1));% Initial guess of state probabilities 
transmat0_5 = mk_stochastic(rand(Q_5,Q_5));% Initial guess of transition probabilities
[mu0_5, Sigma0_5] = mixgauss_init(Q_5*M_5, reshape(data_5, [O_5 T_5*nex_5]), 'full');
mu0_5 = reshape(mu0_5, [O_5 Q_5 M_5]);
Sigma0_5 = reshape(Sigma0_5, [O_5 O_5 Q_5 M_5]);
mixmat0_5 = mk_stochastic(rand(Q_5,M_5));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_5, prior1_5, transmat1_5, mu1_5, Sigma1_5, mixmat1_5] = ... 
mhmm_em(data_5, prior0_5, transmat0_5, mu0_5, Sigma0_5, mixmat0_5, 'max_iter', 40); 

plot (LL_5) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.

%% Training for Low Bit-Bounce (TR_WH_L)
addpath(genpath('C:\Users\HMMall'))
data_6 = [TR_WH_L]';% Training Data Bit Bounce High
T_6 = size(data_6,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_6 = size(data_6,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_6 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_6 = 2; %Number of mixtures of Gaussians 
Q_6 = 4; % Number of hidden states.
left_right_6 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_6 = normalise(rand(Q_6,1));% Initial guess of state probabilities 
transmat0_6 = mk_stochastic(rand(Q_6,Q_6));% Initial guess of transition probabilities
[mu0_6, Sigma0_6] = mixgauss_init(Q_6*M_6, reshape(data_6, [O_6 T_6*nex_6]), 'full');
mu0_6 = reshape(mu0_6, [O_6 Q_6 M_6]);
Sigma0_6 = reshape(Sigma0_6, [O_6 O_6 Q_6 M_6]);
mixmat0_6 = mk_stochastic(rand(Q_6,M_6));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_6, prior1_6, transmat1_6, mu1_6, Sigma1_6, mixmat1_6] = ... 
mhmm_em(data_6, prior0_6, transmat0_6, mu0_6, Sigma0_6, mixmat0_6, 'max_iter', 40); 

plot (LL_6) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.


%% Vibration type classification

testdata = [TST]'; %test data from apparatus readings

PredictedFault = []; 
for i=1:1:size(Prediction,1) 

%Fault_1 Test 
%-------------% 
loglik_1 = mhmm_logprob(testdata(:,i), prior1_1, transmat1_1, mu1_1, Sigma1_1, mixmat1_1);%LL of the trained model given test data.%% 

%Fault_2 Test 
%-------------% 
loglik_2 = mhmm_logprob(testdata(:,i), prior1_2, transmat1_2, mu1_2, Sigma1_2, mixmat1_2);%LL of the trained model given test data.%Fault_3 Test 

%Fault_3 Test 
%-------------% 
loglik_3 = mhmm_logprob(testdata(:,i), prior1_3, transmat1_3, mu1_3, Sigma1_3, mixmat1_3);%LL of the trained model given test data.

%Fault_4 Test 
%-------------% 
loglik_4 = mhmm_logprob(testdata(:,i), prior1_4, transmat1_4, mu1_4, Sigma1_4, mixmat1_4);%LL of the trained model given test data.

%Fault_3 Test 
%-------------% 
loglik_5 = mhmm_logprob(testdata(:,i), prior1_5, transmat1_5, mu1_5, Sigma1_5, mixmat1_5);%LL of the trained model given test data.

%Fault_4 Test 
%-------------% 
loglik_6 = mhmm_logprob(testdata(:,i), prior1_6, transmat1_6, mu1_6, Sigma1_6, mixmat1_4);%LL of the trained model given test data.

LOGLIK = [loglik_1 loglik_2 loglik_3]; 

% [MaxLoglikValue,Fault_Number]=max(LOGLIK); 

if (max(LOGLIK)==LOGLIK(1,1)) 
    PredictedFault = [PredictedFault;1]; 
end 
if (max(LOGLIK)==LOGLIK(1,2)) 
    PredictedFault = [PredictedFault;2]; 
end 
if (max(LOGLIK)==LOGLIK(1,3)) 
   PredictedFault = [PredictedFault;3]; 
end 
end 
