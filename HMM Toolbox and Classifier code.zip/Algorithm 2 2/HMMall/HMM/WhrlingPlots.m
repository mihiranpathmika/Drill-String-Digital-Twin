figure(1)

subplot(3,2,1)
plot(TR_WH_L)
axis([1 0.1e4 -1 3])
xlabel ('(a)')
ylabel ('I (A)/a (m/s^2)')
title ('TR-WH-L-Motor Current and Acceleration')

%%
subplot(3,2,2)
plot(TST_WH_L)
axis([1 2e4 -1 3])
xlabel ('(b)')
ylabel ('I (A)/a (m/s^2)')
title ('TST-WH-L-Motor Current and Acceleration')

%%
subplot(3,2,3)
plot(TR_WH_M)
axis([1 2e4 -1 3])
xlabel ('(c)')
ylabel ('I (A)/a (m/s^2)')
title ('TR-WH-M-Motor Current and Acceleration')

%%
subplot(3,2,4)
plot(TST_WH_M)

axis([1 2e4 -1 3])
xlabel ('(d)')
ylabel ('I (A)/a (m/s^2)')
title ('TST-WH-M-Motor Current and Acceleration')

%%
subplot(3,2,5)
plot(TR_WH_H)
axis([1 2e4 -1 3])
xlabel ('(e)')
ylabel ('I (A)/a (m/s^2)')
title ('TR-WH-H-Motor Current and Acceleration')

%%
subplot(3,2,6)
plot(TST_WH_H)

axis([1500 2e4 -1 3])
xlabel ('(f)')
ylabel ('I (A)/a (m/s^2)')
title ('TST-WH-H-Motor Current and Acceleration')

