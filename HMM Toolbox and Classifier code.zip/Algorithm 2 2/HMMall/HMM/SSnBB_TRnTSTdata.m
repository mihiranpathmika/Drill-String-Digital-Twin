figure(1)

subplot(4,2,1)
plot(TR_SS_M(1:2000,1))
axis([1 0.06e4 1 2])
xlabel ('(a)')
ylabel ('I (A)')
title ('TR-SS-M-Motor Current')

%%
subplot(4,2,2)
plot((-1)*TST_SS_M(1:3000,1))
axis([1 0.3e4 1 2])
xlabel ('(b)')
ylabel ('I (A)')
title ('TST-SS-M-Motor Current')

%%
subplot(4,2,3)
plot(TR_BB_M(1:80000,1))
axis([1 6.5e4 0.75 1.3])
xlabel ('(c)')
ylabel ('I (A)')
title ('TR-BB-M-Motor Current')

%%
subplot(4,2,4)
plot(TST_BB_M(1:3000,1))
axis([1 0.3e4 0.75 1.3])
xlabel ('(d)')
ylabel ('I (A)')
title ('TST-BB-M-Motor Current')

%%
subplot(4,2,5)
plot(TR_SS_M(1:2000,2))
axis([1 0.1e4 -0.4 0.4])
xlabel ('(e)')
ylabel ('a (m/s^2)')
title ('TR-SS-M-Acceleration')

%%
subplot(4,2,6)
plot(TST_SS_M(1:3000,2))
axis([1 0.3e4 -0.4 0.4])
xlabel ('(f)')
ylabel ('a (m/s^2)')
title ('TST-SS-M-Acceleration')

%%
subplot(4,2,7)
plot(TR_BB_M(1:60000,2))
axis([1 6e4 -10 10])
xlabel ('(g)')
ylabel ('a (m/s^2)')
title ('TR-BB-M-Acceleration')

%%
subplot(4,2,8)
plot(TST_BB_M(1:10000,2))
axis([1 1e4 -10 10])
xlabel ('(h)')
ylabel ('a (m/s^2)')
title ('TST-BB-M-Acceleration')



