%%
%The Bond Graph Digital Twin generates training data (TD) to train the ML
%algorithm. The data is for "Stick Slip (SS)", "Bit Bounce (BB)", and "Whirling (WH)" and their
%3 levels "high (H)", "medium (M)" and "low (L)"

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Stick-Slip (SS) %%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Training for High Stick-Slip (TR_SS_H)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_1 = [TR_SS_H]';% Training Data High Stick-Slip
T_1 = size(data_1,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_1 = size(data_1,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_1 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_1 = 2; %Number of mixtures of Gaussians 
Q_1 = 4; % Number of hidden states.
left_right_1 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_1 = normalise(rand(Q_1,1));% Initial guess of state probabilities 
transmat0_1 = mk_stochastic(rand(Q_1,Q_1));% Initial guess of transition probabilities
[mu0_1, Sigma0_1] = mixgauss_init(Q_1*M_1, reshape(data_1, [O_1 T_1*nex_1]), 'full');
mu0_1 = reshape(mu0_1, [O_1 Q_1 M_1]);
Sigma0_1 = reshape(Sigma0_1, [O_1 O_1 Q_1 M_1]);
mixmat0_1 = mk_stochastic(rand(Q_1,M_1));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_1, prior1_1, transmat1_1, mu1_1, Sigma1_1, mixmat1_1] = ... 
mhmm_em(data_1, prior0_1, transmat0_1, mu0_1, Sigma0_1, mixmat0_1, 'max_iter', 40); 

plot (LL_1) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. SS_H Trained!')

%% Training for Medium Stick-Slip (TR_SS_M)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_2 = [TR_SS_M]';% Training Data High Stick-Slip
T_2 = size(data_2,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_2 = size(data_2,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_2 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_2 = 2; %Number of mixtures of Gaussians 
Q_2 = 4; % Number of hidden states.
left_right_2 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_2 = normalise(rand(Q_2,1));% Initial guess of state probabilities 
transmat0_2 = mk_stochastic(rand(Q_2,Q_2));% Initial guess of transition probabilities
[mu0_2, Sigma0_2] = mixgauss_init(Q_2*M_2, reshape(data_2, [O_2 T_2*nex_2]), 'full');
mu0_2 = reshape(mu0_2, [O_2 Q_2 M_2]);
Sigma0_2 = reshape(Sigma0_2, [O_2 O_2 Q_2 M_2]);
mixmat0_2 = mk_stochastic(rand(Q_2,M_2));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_2, prior1_2, transmat1_2, mu1_2, Sigma1_2, mixmat1_2] = ... 
mhmm_em(data_2, prior0_2, transmat0_2, mu0_2, Sigma0_2, mixmat0_2, 'max_iter', 40); 

plot (LL_2) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. SS_M Trained!')
%% Training for Low Stick-Slip (TR_SS_L)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_3 = [TR_SS_L]';% Training Data Low Stick-Slip
T_3 = size(data_3,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_3 = size(data_3,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_3 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_3 = 2; %Number of mixtures of Gaussians 
Q_3 = 4; % Number of hidden states.
left_right_3 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_3 = normalise(rand(Q_3,1));% Initial guess of state probabilities 
transmat0_3 = mk_stochastic(rand(Q_3,Q_3));% Initial guess of transition probabilities
[mu0_3, Sigma0_3] = mixgauss_init(Q_3*M_3, reshape(data_3, [O_3 T_3*nex_3]), 'full');
mu0_3 = reshape(mu0_3, [O_3 Q_3 M_3]);
Sigma0_3 = reshape(Sigma0_3, [O_3 O_3 Q_3 M_3]);
mixmat0_3 = mk_stochastic(rand(Q_3,M_3));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_3, prior1_3, transmat1_3, mu1_3, Sigma1_3, mixmat1_3] = ... 
mhmm_em(data_3, prior0_3, transmat0_3, mu0_3, Sigma0_3, mixmat0_3, 'max_iter', 40); 

plot (LL_3) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. SS_L Trained!')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Bit-Bounce (BB) %%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Training for High Bit Bounce (TR_BB_H)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_4 = [TR_BB_H]';% Training Data High Bit Bounce
T_4 = size(data_4,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_4 = size(data_4,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_4 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_4 = 2; %Number of mixtures of Gaussians 
Q_4 = 4; % Number of hidden states.
left_right_4 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_4 = normalise(rand(Q_4,1));% Initial guess of state probabilities 
transmat0_4 = mk_stochastic(rand(Q_4,Q_4));% Initial guess of transition probabilities
[mu0_4, Sigma0_4] = mixgauss_init(Q_4*M_4, reshape(data_4, [O_4 T_4*nex_4]), 'full');
mu0_4 = reshape(mu0_4, [O_4 Q_4 M_4]);
Sigma0_4 = reshape(Sigma0_4, [O_4 O_4 Q_4 M_4]);
mixmat0_4 = mk_stochastic(rand(Q_4,M_4));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_4, prior1_4, transmat1_4, mu1_4, Sigma1_4, mixmat1_4] = ... 
mhmm_em(data_4, prior0_4, transmat0_4, mu0_4, Sigma0_4, mixmat0_4, 'max_iter', 40); 

plot (LL_4) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. BB_H Trained!')

%% Training for High Bit Bounce (TR_BB_M)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_5 = [TR_BB_M]';% Training Data High Bit Bounce
T_5 = size(data_5,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_5 = size(data_5,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_5 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_5 = 2; %Number of mixtures of Gaussians 
Q_5 = 4; % Number of hidden states.
left_right_5 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_5 = normalise(rand(Q_5,1));% Initial guess of state probabilities 
transmat0_5 = mk_stochastic(rand(Q_5,Q_5));% Initial guess of transition probabilities
[mu0_5, Sigma0_5] = mixgauss_init(Q_5*M_5, reshape(data_5, [O_5 T_5*nex_5]), 'full');
mu0_5 = reshape(mu0_5, [O_5 Q_5 M_5]);
Sigma0_5 = reshape(Sigma0_5, [O_5 O_5 Q_5 M_5]);
mixmat0_5 = mk_stochastic(rand(Q_5,M_5));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_5, prior1_5, transmat1_5, mu1_5, Sigma1_5, mixmat1_5] = ... 
mhmm_em(data_5, prior0_5, transmat0_5, mu0_5, Sigma0_5, mixmat0_5, 'max_iter', 40); 

plot (LL_5) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. BB_M Trained!')

%% Training for Low Bit-Bounce (TR_BB_L)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_6 = [TR_BB_L]';% Training Data Low Bit-Bounce
T_6 = size(data_6,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_6 = size(data_6,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_6 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_6 = 2; %Number of mixtures of Gaussians 
Q_6 = 4; % Number of hidden states.
left_right_6 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_6 = normalise(rand(Q_6,1));% Initial guess of state probabilities 
transmat0_6 = mk_stochastic(rand(Q_6,Q_6));% Initial guess of transition probabilities
[mu0_6, Sigma0_6] = mixgauss_init(Q_6*M_6, reshape(data_6, [O_6 T_6*nex_6]), 'full');
mu0_6 = reshape(mu0_6, [O_6 Q_6 M_6]);
Sigma0_6 = reshape(Sigma0_6, [O_6 O_6 Q_6 M_6]);
mixmat0_6 = mk_stochastic(rand(Q_6,M_6));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_6, prior1_6, transmat1_6, mu1_6, Sigma1_6, mixmat1_6] = ... 
mhmm_em(data_6, prior0_6, transmat0_6, mu0_6, Sigma0_6, mixmat0_6, 'max_iter', 40); 

plot (LL_6) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. BB_L Trained!')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Whirling (Forward) (WH) %%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Training for High Whirling (TR_WH_H)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_7 = [TR_WH_H]';% Training Data High Bit Bounce
T_7 = size(data_7,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_7 = size(data_7,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_7 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_7 = 2; %Number of mixtures of Gaussians 
Q_7 = 4; % Number of hidden states.
left_right_7 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_7 = normalise(rand(Q_7,1));% Initial guess of state probabilities 
transmat0_7 = mk_stochastic(rand(Q_7,Q_7));% Initial guess of transition probabilities
[mu0_7, Sigma0_7] = mixgauss_init(Q_7*M_7, reshape(data_7, [O_7 T_7*nex_7]), 'full');
mu0_7 = reshape(mu0_7, [O_7 Q_7 M_7]);
Sigma0_7 = reshape(Sigma0_7, [O_7 O_7 Q_7 M_7]);
mixmat0_7 = mk_stochastic(rand(Q_7,M_7));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_7, prior1_7, transmat1_7, mu1_7, Sigma1_7, mixmat1_7] = ... 
mhmm_em(data_7, prior0_7, transmat0_7, mu0_7, Sigma0_7, mixmat0_7, 'max_iter', 40); 

plot (LL_7) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. WH_H Trained!')

%% Training for Medium Whirling  (TR_WH_M)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_8 = [TR_WH_M]';% Training Data Medium Whrling
T_8 = size(data_8,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_8 = size(data_8,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_8 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_8 = 2; %Number of mixtures of Gaussians 
Q_8 = 4; % Number of hidden states.
left_right_8 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_8 = normalise(rand(Q_8,1));% Initial guess of state probabilities 
transmat0_8 = mk_stochastic(rand(Q_8,Q_8));% Initial guess of transition probabilities
[mu0_8, Sigma0_8] = mixgauss_init(Q_8*M_8, reshape(data_8, [O_8 T_8*nex_8]), 'full');
mu0_8 = reshape(mu0_8, [O_8 Q_8 M_8]);
Sigma0_8 = reshape(Sigma0_8, [O_8 O_8 Q_8 M_8]);
mixmat0_8 = mk_stochastic(rand(Q_8,M_8));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_8, prior1_8, transmat1_8, mu1_8, Sigma1_8, mixmat1_8] = ... 
mhmm_em(data_8, prior0_8, transmat0_8, mu0_8, Sigma0_8, mixmat0_8, 'max_iter', 40); 

plot (LL_8) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. WH_M Trained!')

%% Training for Low Whirling (TR_WH_L)
addpath(genpath('C:\Users\mihir\OneDrive\1_Mihiran\1_PhD_MUN\1_Project\2_Publications\Paper_04_Digital_Twin\Algorithm 2\HMMall'))
data_9 = [TR_WH_L]';% Training Data Low Whirling
T_9 = size(data_9,2); % The number of observation sequences. In other words, "How many data sample strings?" or the number of raws
O_9 = size(data_9,1); % The number of sensor data in a given sequence i.e. Motor Current, Accelerometer, and ang speed or teh number of columns
nex_9 = 1; % the different layers of data in the 3D matrix. (May be the data from another similar process line)
M_9 = 3; %Number of mixtures of Gaussians 
Q_9 = 9; % Number of hidden states.
left_right_9 = 0; %Left-right architecture of the HMM model, 'yes' or 'no'
prior0_9 = normalise(rand(Q_9,1));% Initial guess of state probabilities 
transmat0_9 = mk_stochastic(rand(Q_9,Q_9));% Initial guess of transition probabilities
[mu0_9, Sigma0_9] = mixgauss_init(Q_9*M_9, reshape(data_9, [O_9 T_9*nex_9]), 'full');
mu0_9 = reshape(mu0_9, [O_9 Q_9 M_9]);
Sigma0_9 = reshape(Sigma0_9, [O_9 O_9 Q_9 M_9]);
mixmat0_9 = mk_stochastic(rand(Q_9,M_9));
%Finally, let us improve these parameter estimates using Expectation Maximization Algorithm. 
[LL_9, prior1_9, transmat1_9, mu1_9, Sigma1_9, mixmat1_9] = ... 
mhmm_em(data_9, prior0_9, transmat0_9, mu0_9, Sigma0_9, mixmat0_9, 'max_iter', 40); 

plot (LL_9) % Plotting the improvement of the Log Likelihood after 5 iterations. the learning curve.
xlabel ('Number of data strings')
ylabel ('Log-likelihood')

disp('Log-likelihood becomes consistent. WH_L Trained!')


%% Vibration type and severity classification
%%%%%%%%%%%% Input the testing data here %%%%%%%%%%%%%%%%%%%%
testdata = [TST_WH_L(:,:)]';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

LLike_1 = [];
for i=1:1:size(testdata,2) 
loglik_1 = mhmm_logprob(testdata(:,i), prior1_1, transmat1_1, mu1_1, Sigma1_1, mixmat1_1);
LLike_1 = [LLike_1; loglik_1];
end

MEAN_1 = mean (LLike_1);

LLike_2 = [];
for i=1:1:size(testdata,2) 
loglik_2 = mhmm_logprob(testdata(:,i), prior1_2, transmat1_2, mu1_2, Sigma1_2, mixmat1_2);
LLike_2 = [LLike_2; loglik_2];
end

MEAN_2 = mean (LLike_2);

LLike_3 = [];
for i=1:1:size(testdata,2) 
loglik_3 = mhmm_logprob(testdata(:,i), prior1_3, transmat1_3, mu1_3, Sigma1_3, mixmat1_3);
LLike_3 = [LLike_3; loglik_3];
end

MEAN_3 = mean (LLike_3);

LLike_4 = [];
for i=1:1:size(testdata,2) 
loglik_4 = mhmm_logprob(testdata(:,i), prior1_4, transmat1_4, mu1_4, Sigma1_4, mixmat1_4);
LLike_4 = [LLike_4; loglik_4];
end

MEAN_4 = mean (LLike_4);

LLike_5 = [];
for i=1:1:size(testdata,2) 
loglik_5 = mhmm_logprob(testdata(:,i), prior1_5, transmat1_5, mu1_5, Sigma1_5, mixmat1_5);
LLike_5 = [LLike_5; loglik_5];
end

MEAN_5 = mean (LLike_5);

LLike_6 = [];
for i=1:1:size(testdata,2) 
loglik_6 = mhmm_logprob(testdata(:,i), prior1_6, transmat1_6, mu1_6, Sigma1_6, mixmat1_6);
LLike_6 = [LLike_6; loglik_6];
end

MEAN_6 = mean (LLike_6);

LLike_7 = [];
for i=1:1:size(testdata,2) 
loglik_7 = mhmm_logprob(testdata(:,i), prior1_7, transmat1_7, mu1_7, Sigma1_7, mixmat1_7);
LLike_7 = [LLike_7; loglik_7];
end

MEAN_7 = mean (LLike_7);

LLike_8 = [];
for i=1:1:size(testdata,2) 
loglik_8 = mhmm_logprob(testdata(:,i), prior1_8, transmat1_8, mu1_8, Sigma1_8, mixmat1_8);
LLike_8 = [LLike_8; loglik_8];
end

MEAN_8 = mean (LLike_8);

LLike_9 = [];
for i=1:1:size(testdata,2) 
loglik_9 = mhmm_logprob(testdata(:,i), prior1_9, transmat1_9, mu1_9, Sigma1_9, mixmat1_9);
LLike_9 = [LLike_9; loglik_9];
end

MEAN_9 = mean (LLike_9);

MEANS = [MEAN_1 MEAN_2 MEAN_3 MEAN_4 MEAN_5 MEAN_6 MEAN_7 MEAN_8 MEAN_9];

if max (MEANS) == MEAN_1
    disp('Stick Slip - High')
end

if max (MEANS) == MEAN_2
    disp('Stick Slip - Medium')
end

if max (MEANS) == MEAN_3
    disp('Stick Slip - Low')
end

if max (MEANS) == MEAN_4
    disp('Bit Bounce- High')
end

if max (MEANS) == MEAN_5
    disp('Bit Bounce- Medium')
end

if max (MEANS) == MEAN_6
    disp('Bit Bounce- Low')
end

if max (MEANS) == MEAN_7
    disp('Whirling- High')
end

if max (MEANS) == MEAN_8
    disp('Whirling- Medium')
end

if max (MEANS) == MEAN_9
    disp('Whirling- Low')
end
%%
figure(1)

subplot(3,3,1)
plot(LLike_1)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,2)
plot(LLike_2)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,3)
plot(LLike_3)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,4)
plot(LLike_4)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,5)
plot(LLike_5)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,6)
plot(LLike_6)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,7)
plot(LLike_7)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,8)
plot(LLike_8)
xlabel ('Data string #')
ylabel ('Log-likelihood')

subplot(3,3,9)
plot(LLike_9)
xlabel ('Data string #')
ylabel ('Log-likelihood')
