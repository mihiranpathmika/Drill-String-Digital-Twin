figure(1)

subplot(5,2,1)
plot(TR_SS_M)
axis([1 0.5e4 -10 10])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TR-SS-M')
%%
subplot(5,2,2)
plot(TST_SS_M)
axis([1 0.4e4 -10 10])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TST-SS-M')
%%
subplot(5,2,3)
plot(TR_BB_M)
axis([1 8e4 -10 10])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TR-BB-M')
%%
subplot(5,2,4)
plot(TST_BB_M)
axis([1 1e4 -10 10])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TST-BB-M')
%%

subplot(5,2,5)
plot(TR_WH_L)
axis([1 2e4 -1 3])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TR-WH-L')
%%

subplot(5,2,6)
plot(TST_WH_L)
axis([1 2e4 -1 3])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TST-WH-L')
%%
subplot(5,2,7)
plot(TR_WH_M)
axis([1 2e4 -1 3])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TR-WH-M')

%%
subplot(5,2,8)
plot(TST_WH_M)
axis([1 2e4 -1 3])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TST-WH-M')
%%
subplot(5,2,9)
plot(TR_WH_H)
axis([1 2e4 -1 3])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TR-WH-H')

%%
subplot(5,2,10)
plot(TST_WH_H)
axis([1 2e4 -1 3])
xlabel ('Data strings (nos)')
ylabel ('Amplitude')
title ('TST-WH-H')

