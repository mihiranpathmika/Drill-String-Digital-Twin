x = linspace(0,2*pi);
y = sin(x);
plot(x,y,'-o')
axis([0 2*pi -1.5 1.5])